SET search_path TO vente_velo;

--1) Combien chaque utilisateur a de commandes qui ont été annulées ?

SELECT u.nom, COUNT(c.id_commande) AS nb_commandes_annulees
FROM utilisateur u INNER JOIN commande c ON u.id_utilisateur = c.utilisateur_id 
INNER JOIN etat e ON e.id_etat=c.etat_id
WHERE e.libelle = 'Annulée'
GROUP BY u.nom;

--  nom   | nb_commandes_annulees 
----------+-----------------------
-- Kaya   |                     1
-- Leroy  |                     1
-- Tanaka |                     1
--(3 rows)


--2)Quels sont les vélos qui n'ont jamais été commandés ?
SELECT v.id_velo, v.nom_velo
FROM velo v LEFT JOIN ligne_commande lc ON v.id_velo = lc.velo_id
WHERE lc.velo_id IS NULL;

--ou
SELECT id_velo, nom_velo
FROM velo 
EXCEPT
SELECT v.id_velo, v.nom_velo
FROM velo v INNER JOIN ligne_commande lc ON v.id_velo = lc.velo_id;

-- id_velo |          nom_velo          
-----------+----------------------------
--      49 | Mongoose Legion L100
--      33 | Cannondale Moterra Neo
--      32 | Orbea Gain M20
--      42 | Cannondale Topstone Carbon
--      29 | Giant Trance X E+
--      47 | Sunday Soundwave Special
--      35 | Merida eOne-Sixty
--      16 | Kona Mahuna
--      44 | Scott Addict Gravel 30
--      31 | Cube Kathmandu Hybrid
--      50 | Haro Downtown DLX
--      18 | Specialized Tarmac SL7
--      20 | Giant Defy Advanced
--      48 | Subrosa Tiro XL
--(14 rows)


--3) Quel est le type de vélo le plus vendu et combien d’unités ont été vendues ?
SELECT tv.libelle_type_velo, SUM(lc.quantite) AS total_vendus
FROM ligne_commande lc INNER JOIN velo v ON lc.velo_id = v.id_velo
INNER JOIN type_velo tv ON v.type_velo_id = tv.id_type_velo
GROUP BY tv.libelle_type_velo
ORDER BY total_vendus DESC
LIMIT 1;

--ou 
SELECT tv.libelle_type_velo, SUM(lc.quantite) AS total_vendus
FROM ligne_commande lc INNER JOIN velo v ON lc.velo_id = v.id_velo
INNER JOIN type_velo tv ON v.type_velo_id = tv.id_type_velo
GROUP BY tv.libelle_type_velo
HAVING SUM(lc.quantite) = (SELECT MAX(total_vendus)
                        	FROM (SELECT SUM(lc.quantite) AS total_vendus
                                  	FROM ligne_commande lc INNER JOIN velo v ON lc.velo_id = v.id_velo
                                	INNER JOIN type_velo tv ON v.type_velo_id = tv.id_type_velo
                                	GROUP BY tv.libelle_type_velo) AS total_vendus_velo);

-- libelle_type_velo | total_vendus 
---------------------+--------------
-- VTT               |           17
--(1 row)


--4) Quels sont les fournisseurs qui génèrent le plus de ventes indirectes ?

SELECT v.fournisseur, SUM(lc.quantite) AS total_ventes_indirectes
FROM ligne_commande lc INNER JOIN velo v ON lc.velo_id = v.id_velo
GROUP BY  v.fournisseur
HAVING SUM(lc.quantite) = (SELECT MAX(ventes)
							FROM (SELECT SUM(lc.quantite) AS ventes
							FROM ligne_commande lc INNER JOIN velo v ON lc.velo_id = v.id_velo
							GROUP BY  v.fournisseur) AS quantite_max_fournisseur);

-- fournisseur | total_ventes_indirectes 
---------------+-------------------------
-- Rapidevelo  |                      14
--(1 row)


--5) Créer une vue V1 qui affiche pour chaque utilisateur la somme totale de ses commandes et son nombre total de commandes..

CREATE VIEW v1 AS
SELECT u.id_utilisateur, u.nom, COUNT(c.id_commande) AS nb_commandes, SUM(lc.prix * lc.quantite) AS total_commande
FROM utilisateur u LEFT JOIN commande c ON u.id_utilisateur = c.utilisateur_id
LEFT JOIN ligne_commande lc ON c.id_commande = lc.commande_id
GROUP BY u.id_utilisateur;

SELECT * FROM v1;

-- id_utilisateur |    nom    | nb_commandes | total_commande 
------------------+-----------+--------------+----------------
--             51 | Mensah    |            0 |               
--             22 | Rahmani   |            1 |           5400
--             11 | Zahra     |            0 |               
--             44 | Haddad    |            1 |           9500
--             42 | Benamara  |            2 |           4200
--             40 | Martinez  |            1 |           4200
--             43 | Sow       |            1 |           2000
--              9 | Lopes     |            2 |           2450
--             15 | Selim     |            1 |           6200
--             26 | Yilmaz    |            0 |               
--             48 | Ambrosini |            1 |           5100
--             19 | Vu        |            0 |               
--             30 | Da Silva  |            1 |           6800
--             21 | Kuznetsov |            0 |               
--              3 | Morel     |            2 |           4100
--             17 | Rodriquez |            1 |           3700
--             28 | Fang      |            0 |               
--             37 | Ezra      |            0 |               
--              5 | Fontaine  |            2 |           5900
--             29 | Ali       |            0 |               
--              4 | Bertrand  |            0 |               
--             34 | Bensaid   |            0 |               
--             10 | Petrovic  |            1 |            900
--             35 | Gomes     |            1 |           3100
--             45 | Jung      |            1 |          12000
--              6 | Leroy     |            1 |           2600
--             39 | Soumahoro |            0 |               
--             36 | Bianchi   |            0 |               
--             31 | Zhang     |            0 |               
--             50 | Kaya      |            1 |           3500
--             14 | Tran      |            0 |               
--             13 | Boukhris  |            1 |           3600
--              2 | Dupont    |            0 |               
--             16 | Cho       |            0 |               
--             41 | Costa     |            1 |           3000
--             46 | Chowdhury |            1 |           5600
--             32 | Okafor    |            1 |           2700
--              7 | Benali    |            1 |           1900
--             38 | Tanaka    |            1 |           4400
--             12 | Kimani    |            2 |           4100
--             24 | Borges    |            0 |               
--             25 | Hassan    |            0 |               
--             49 | Zhao      |            1 |           5700
--             47 | Boukhalfa |            1 |           4900
--             20 | Daoud     |            0 |               
--             33 | Johansson |            0 |               
--              1 | Garnier   |            1 |           3800
--             18 | Mokhtar   |            2 |           9600
--             27 | Dumitru   |            1 |           2500
--             23 | Goldstein |            2 |           5300
--              8 | Wei       |            0 |               
--(51 rows)