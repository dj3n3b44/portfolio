SET search_path TO vente_velo;


INSERT INTO utilisateur(login_utilisateur, email, nom, pwd, user_role) VALUES
	('tgarnier', 'tgarnier@vente_velo.fr', 'Garnier', 'garniert', 'client'),
	('ldupont', 'ldupont@vente_velo.fr', 'Dupont', 'dupontl', 'client'),
	('jmorel', 'jmorel@vente_velo.fr', 'Morel', 'morelj', 'client'),
	('cbertrand', 'cbertrand@vente_velo.fr', 'Bertrand', 'bertrandc', 'vendeur'),
	('lfontaine', 'lfontaine@vente_velo.fr', 'Fontaine', 'fontainej', 'client'),
	('sleroy', 'sleroy@vente_velo.fr', 'Leroy', 'leroys', 'client'),
	('ahmedb', 'ahmed.benali@vente_velo.fr', 'Benali', 'benalia', 'client'),
	('liwei', 'li.wei@vente_velo.fr', 'Wei', 'weili', 'client'),
	('marial', 'maria.lopes@vente_velo.fr', 'Lopes', 'lopesm', 'client'),
	('draganp', 'dragan.petrovic@vente_velo.fr', 'Petrovic', 'petrovicd', 'client'),
	('fatimaz', 'fatima.zahra@vente_velo.fr', 'Zahra', 'zahraf', 'client'),
	('johnk', 'john.kimani@vente_velo.fr', 'Kimani', 'kimanij', 'client'),
	('hananb', 'hanan.boukhris@vente_velo.fr', 'Boukhris', 'boukhrish', 'client'),
	('yasminet', 'yasmine.tran@vente_velo.fr', 'Tran', 'trany', 'client'),
	('mehdis', 'mehdi.selim@vente_velo.fr', 'Selim', 'selimm', 'client'),
	('alexc', 'alex.cho@vente_velo.fr', 'Cho', 'choa', 'client'),
	('kevinr', 'kevin.rodriquez@vente_velo.fr', 'Rodriquez', 'rodriquezk', 'client'),
	('inesm', 'ines.mokhtar@vente_velo.fr', 'Mokhtar', 'mokhtari', 'client'),
	('pierrev', 'pierre.vu@vente_velo.fr', 'Vu', 'vup', 'client'),
	('leilad', 'leila.daoud@vente_velo.fr', 'Daoud', 'daoudl', 'client'),
	('ivank', 'ivan.kuznetsov@vente_velo.fr', 'Kuznetsov', 'kuznetsovi', 'client'),
	('amalr', 'amal.rahmani@vente_velo.fr', 'Rahmani', 'rahmania', 'client'),
	('davidg', 'david.goldstein@vente_velo.fr', 'Goldstein', 'goldsteind', 'client'),
	('julianb', 'julian.borges@vente_velo.fr', 'Borges', 'borgesj', 'client'),
	('noorh', 'noor.hassan@vente_velo.fr', 'Hassan', 'hassann', 'client'),
	('karimy', 'karim.yilmaz@vente_velo.fr', 'Yilmaz', 'yilmazk', 'client'),
	('sabinad', 'sabina.dumitru@vente_velo.fr', 'Dumitru', 'dumitrus', 'client'),
	('emmanuelf', 'emmanuel.fang@vente_velo.fr', 'Fang', 'fange', 'client'),
	('tariqa', 'tariq.ali@vente_velo.fr', 'Ali', 'alit', 'client'),
	('clarad', 'clara.dasilva@vente_velo.fr', 'Da Silva', 'dasilvac', 'client'),
	('zhanga', 'zhang.ao@vente_velo.fr', 'Zhang', 'zhanga', 'client'),
	('milenao', 'milena.okafor@vente_velo.fr', 'Okafor', 'okaform', 'client'),
	('emilj', 'emil.johansson@vente_velo.fr', 'Johansson', 'johanssone', 'client'),
	('raniab', 'rania.bensaid@vente_velo.fr', 'Bensaid', 'bensaidr', 'client'),
	('joaog', 'joao.gomes@vente_velo.fr', 'Gomes', 'gomesj', 'client'),
	('sofiab', 'sofia.bianchi@vente_velo.fr', 'Bianchi', 'bianchis', 'client'),
	('thomase', 'thomas.ezra@vente_velo.fr', 'Ezra', 'ezrat', 'client'),
	('aminet', 'amine.tanaka@vente_velo.fr', 'Tanaka', 'tanakaa', 'client'),
	('naimas', 'naima.soumahoro@vente_velo.fr', 'Soumahoro', 'soumahoron', 'client'),
	('andream', 'andrea.martinez@vente_velo.fr', 'Martinez', 'martineza', 'client'),
	('leoc', 'leo.costa@vente_velo.fr', 'Costa', 'costal', 'client'),
	
	
	-- VENDEURS (5)
	('safiab', 'safia.benamara@vente_velo.fr', 'Benamara', 'benamaras', 'vendeur'),
	('adams', 'adam.sow@vente_velo.fr', 'Sow', 'sowa', 'vendeur'),
	('lucienh', 'lucien.haddad@vente_velo.fr', 'Haddad', 'haddadl', 'vendeur'),
	('mariej', 'marie.jung@vente_velo.fr', 'Jung', 'jungm', 'vendeur'),
	('eliasc', 'elias.chowdhury@vente_velo.fr', 'Chowdhury', 'chowdhurye', 'vendeur'),
	
	
	-- ADMINS (5)
	('syrineb', 'syrine.boukhalfa@vente_velo.fr', 'Boukhalfa', 'boukhalfas', 'admin'),
	('jeromea', 'jerome.ambrosini@vente_velo.fr', 'Ambrosini', 'ambrosinij', 'admin'),
	('farahz', 'farah.zhao@vente_velo.fr', 'Zhao', 'zhaof', 'admin'),
	('mehmetk', 'mehmet.kaya@vente_velo.fr', 'Kaya', 'kayam', 'admin'),
	('dianem', 'diane.mensah@vente_velo.fr', 'Mensah', 'mensahd', 'admin');

INSERT INTO etat (libelle) VALUES
	('En attente'),
	('Expédiée'),
	('Livrée'),
	('Annulée');

INSERT INTO taille (libelle_taille) VALUES
	('XS'),
	('S'),
	('M'),
	('L'),
	('XL');

INSERT INTO type_velo  (libelle_type_velo) VALUES
	('VTT'),
	('Vélo de route'),
	('Vélo électrique'),
	('Gravel'),
	('BMX');

INSERT INTO velo (nom_velo, prix_velo, taille_id, type_velo_id, matiere, description_velo, fournisseur, marque) VALUES
    ('Trek Marlin 7', 850, 2, 1, 'Aluminium', 'VTT performant', 'Rapidevelo', 'Trek'),
    ('Specialized Rockhopper', 750, 3, 1, 'Aluminium', 'Idéal pour le trail', 'Ecocycle', 'Specialized'),
    ('Cannondale Trail 8', 600, 2, 1, 'Aluminium', 'Parfait pour débuter', 'BikeOne', 'Cannondale'),
    ('Giant TCR Advanced', 2500, 4, 2, 'Carbone', 'Compétition route', 'VeloRice', 'Giant'),
    ('Bianchi Sprint', 2800, 3, 2, 'Carbone', 'Rapide et léger', 'Rapidevelo', 'Bianchi'),
    ('Scott Aspect 950', 700, 3, 1, 'Aluminium', 'VTT robuste', 'Ecocycle', 'Scott'),
    ('Santa Cruz Chameleon', 1900, 3, 1, 'Aluminium', 'Polyvalent et agile', 'BikeOne', 'Santa Cruz'),
    ('Orbea Alma M50', 1800, 3, 1, 'Carbone', 'VTT léger et rapide', 'VeloRice', 'Orbea'),
    ('Canyon Exceed CF 7', 2200, 4, 1, 'Carbone', 'Performance XC', 'Rapidevelo', 'Canyon'),
    ('YT Jeffsy Core 2', 2600, 4, 1, 'Aluminium', 'Trail agressif', 'Ecocycle', 'YT'),
    ('Mondraker Foxy R', 3500, 4, 1, 'Carbone', 'Enduro polyvalent', 'BikeOne', 'Mondraker'),
    ('Lapierre Zesty AM 5.0', 2900, 3, 1, 'Carbone', 'Idéal pour l all-mountain', 'VeloRice', 'Lapierre'),
    ('Cube Stereo 120', 2000, 3, 1, 'Aluminium', 'Suspension intégrale', 'Rapidevelo', 'Cube'),
    ('Merida Big Nine 500', 1300, 2, 1, 'Aluminium', 'Semi-rigide performant', 'Ecocycle', 'Merida'),
    ('GT Avalanche Comp', 900, 2, 1, 'Aluminium', 'Bon rapport qualité/prix', 'BikeOne', 'GT'),
    ('Kona Mahuna', 1100, 3, 1, 'Aluminium', 'VTT trail maniable', 'VeloRice', 'Kona'),
    ('Trek Domane SL 6', 3700, 4, 2, 'Carbone', 'Confort longue distance', 'Rapidevelo', 'Trek'),
    ('Specialized Tarmac SL7', 5300, 4, 2, 'Carbone', 'Ultra léger et rapide', 'Ecocycle', 'Specialized'),
    ('Cannondale SuperSix Evo', 4500, 4, 2, 'Carbone', 'Aérodynamique et nerveux', 'BikeOne', 'Cannondale'),
    ('Giant Defy Advanced', 3200, 4, 2, 'Carbone', 'Endurance et confort', 'VeloRice', 'Giant'),
    ('Bianchi Oltre XR4', 6800, 4, 2, 'Carbone', 'Vélo de compétition', 'Rapidevelo', 'Bianchi'),
    ('Scott Addict RC 30', 4200, 4, 2, 'Carbone', 'Léger et rigide', 'Ecocycle', 'Scott'),
    ('Colnago C64', 9500, 4, 2, 'Carbone', 'Fabriqué à la main en Italie', 'BikeOne', 'Colnago'),
    ('Pinarello Dogma F12', 12000, 4, 2, 'Carbone', 'Utilisé par les pros', 'VeloRice', 'Pinarello'),
    ('Cervélo R5', 7000, 4, 2, 'Carbone', 'Haute performance', 'Rapidevelo', 'Cervélo'),
    ('Ridley Noah Fast', 6200, 4, 2, 'Carbone', 'Rapide et aérodynamique', 'Ecocycle', 'Ridley'),
    ('Trek Powerfly 5', 4200, 3, 3, 'Aluminium', 'VTT électrique puissant', 'BikeOne', 'Trek'),
    ('Specialized Turbo Levo', 5600, 3, 3, 'Carbone', 'VTT électrique performant', 'VeloRice', 'Specialized'),
    ('Giant Trance X E+', 5200, 3, 3, 'Aluminium', 'E-bike tout-terrain', 'Rapidevelo', 'Giant'),
    ('Bulls Copperhead EVO AM', 4800, 3, 3, 'Aluminium', 'Polyvalent et puissant', 'Ecocycle', 'Bulls'),
    ('Cube Kathmandu Hybrid', 3800, 3, 3, 'Aluminium', 'Confort et autonomie', 'BikeOne', 'Cube'),
    ('Orbea Gain M20', 4500, 3, 3, 'Carbone', 'Vélo électrique léger', 'VeloRice', 'Orbea'),
    ('Cannondale Moterra Neo', 5700, 3, 3, 'Carbone', 'Performance en montagne', 'Rapidevelo', 'Cannondale'),
    ('Lapierre Overvolt AM', 4900, 3, 3, 'Aluminium', 'Parfait pour l enduro électrique', 'Ecocycle', 'Lapierre'),
    ('Merida eOne-Sixty', 5100, 3, 3, 'Aluminium', 'Conçu pour l aventure', 'BikeOne', 'Merida'),
    ('Haibike AllMtn 7', 5300, 3, 3, 'Aluminium', 'VTT électrique robuste', 'VeloRice', 'Haibike'),
    ('Canyon Grail CF SL 7', 2500, 3, 4, 'Carbone', 'Gravel polyvalent', 'Rapidevelo', 'Canyon'),
    ('Specialized Diverge', 2700, 3, 4, 'Carbone', 'Idéal pour l aventure', 'Ecocycle', 'Specialized'),
    ('Trek Checkpoint SL 6', 3100, 3, 4, 'Carbone', 'Stabilité et vitesse', 'BikeOne', 'Trek'),
    ('Giant Revolt Advanced', 2900, 3, 4, 'Carbone', 'Confort et performance', 'VeloRice', 'Giant'),
    ('Bianchi Impulso Allroad', 2600, 3, 4, 'Aluminium', 'Exploration sans limites', 'Rapidevelo', 'Bianchi'),
    ('Cannondale Topstone Carbon', 3200, 3, 4, 'Carbone', 'Gravel avec suspension', 'Ecocycle', 'Cannondale'),
    ('Orbea Terra H30', 2300, 3, 4, 'Aluminium', 'Rapide et robuste', 'BikeOne', 'Orbea'),
    ('Scott Addict Gravel 30', 3000, 3, 4, 'Carbone', 'Prêt pour l aventure', 'VeloRice', 'Scott'),
    ('Ridley Kanzo Fast', 3500, 3, 4, 'Carbone', 'Performance sur route et gravel', 'Rapidevelo', 'Ridley'),
    ('GT Performer 21', 700, 2, 5, 'Acier', 'BMX freestyle', 'Ecocycle', 'GT'),
    ('Sunday Soundwave Special', 1200, 2, 5, 'Acier', 'Idéal pour le park', 'BikeOne', 'Sunday'),
    ('Subrosa Tiro XL', 650, 2, 5, 'Acier', 'Robuste et stable', 'VeloRice', 'Subrosa'),
    ('Mongoose Legion L100', 750, 2, 5, 'Acier', 'Parfait pour les tricks', 'Rapidevelo', 'Mongoose'),
    ('Haro Downtown DLX', 600, 2, 5, 'Acier', 'Polyvalent et abordable', 'Ecocycle', 'Haro');


INSERT INTO commande (date_achat, utilisateur_id, etat_id) VALUES
	('2024-12-15', 3, 1),
	('2024-11-27', 7, 2),
	('2024-12-01', 12, 1),
	('2025-01-05', 15, 3),
	('2025-01-17', 22, 1),
	('2024-11-22', 6, 4),
	('2025-02-10', 9, 2),
	('2025-02-14', 1, 1),
	('2025-03-01', 18, 2),
	('2025-03-11', 30, 3),
	('2025-01-25', 5, 1),
	('2025-02-02', 10, 1),
	('2025-02-17', 13, 2),
	('2025-03-05', 17, 3),
	('2025-03-10', 23, 1),
	('2025-03-15', 27, 1),
	('2025-03-20', 32, 2),
	('2025-03-25', 35, 3),
	('2025-04-01', 38, 4),
	('2025-04-03', 40, 1),
	('2025-04-04', 41, 2),
	('2025-04-05', 42, 1),
	('2025-04-06', 43, 3),
	('2025-04-07', 44, 1),
	('2025-04-08', 45, 2),
	('2025-04-08', 46, 1),
	('2025-04-08', 47, 1),
	('2025-04-09', 48, 2),
	('2025-04-09', 49, 3),
	('2025-04-10', 50, 4);


INSERT INTO ligne_commande (commande_id, velo_id, prix, quantite) VALUES
	(1, 12, 2900, 1),
	(1, 3, 600, 2),
	
	(2, 7, 1900, 1),
	
	(3, 14, 1300, 1),
	(3, 5, 2800, 1),
	
	(4, 25, 6200, 1),
	
	(5, 41, 2700, 2),
	
	(6, 10, 2600, 1),
	
	(7, 1, 850, 2),
	(7, 2, 750, 1),
	
	(8, 30, 3800, 1),
	
	(9, 34, 5100, 1),
	(9, 19, 4500, 1),
	
	(10, 21, 6800, 1),
	
	(11, 6, 700, 1),
	(11, 28, 5200, 1),
	
	(12, 15, 900, 1),
	
	(13, 8, 1800, 2),
	
	(14, 17, 3700, 1),
	
	(15, 4, 2500, 1),
	(15, 5, 2800, 1),
	
	(16, 38, 2500, 1),
	
	(17, 39, 2700, 1),
	
	(18, 40, 3100, 1),
	
	(19, 9, 2200, 2),
	
	(20, 22, 4200, 1),
	
	(21, 43, 3000, 1),
	
	(22, 45, 3500, 1),
	(22, 46, 700, 1),
	
	(23, 13, 2000, 1),
	
	(24, 23, 9500, 1),
	
	(25, 24, 12000, 1),
	
	(26, 26, 5600, 1),
	
	(27, 36, 4900, 1),
	
	(28, 37, 5100, 1),
	
	(29, 27, 5700, 1),
	
	(30, 11, 3500, 1);
	

INSERT INTO ligne_panier (utilisateur_id, velo_id, quantite, date_ajout) VALUES
	(4, 12, 1, '2025-03-01'),
	(6, 28, 2, '2025-03-02'),
	(9, 34, 1, '2025-03-04'),
	(10, 5, 1, '2025-03-05'),
	(12, 22, 1, '2025-03-06'),
	(14, 7, 2, '2025-03-08'),
	(18, 1, 1, '2025-03-10'),
	(20, 41, 1, '2025-03-11'),
	(21, 15, 1, '2025-03-12'),
	(23, 3, 2, '2025-03-13'),
	(24, 19, 1, '2025-03-14'),
	(25, 31, 1, '2025-03-14'),
	(27, 36, 1, '2025-03-15'),
	(28, 2, 1, '2025-03-16'),
	(30, 13, 1, '2025-03-17'),
	(32, 8, 1, '2025-03-18'),
	(33, 18, 2, '2025-03-18'),
	(34, 29, 1, '2025-03-19'),
	(35, 6, 1, '2025-03-20'),
	(36, 42, 1, '2025-03-21'),
	(38, 45, 2, '2025-03-22'),
	(39, 39, 1, '2025-03-23'),
	(40, 17, 1, '2025-03-24'),
	(42, 10, 1, '2025-03-25'),
	(43, 25, 1, '2025-03-25'),
	(44, 50, 1, '2025-03-26'),
	(46, 20, 2, '2025-03-26'),
	(47, 44, 1, '2025-03-27'),
	(48, 27, 1, '2025-03-28'),
	(50, 9, 1, '2025-03-28');