SET search_path TO vente_velo; --schéma à utiliser
DROP SCHEMA IF EXISTS vente_velo CASCADE; --suppression du schéma s'il existe déjà
CREATE SCHEMA vente_velo; --création d’un nouveau schéma

--table des utilisateurs
CREATE TABLE utilisateur (
    id_utilisateur SERIAL PRIMARY KEY NOT NULL,
    login_utilisateur VARCHAR(35) NOT NULL,
    email VARCHAR(35) NOT NULL,
    nom VARCHAR(35) NOT NULL,
    pwd VARCHAR(35) NOT NULL,
    user_role VARCHAR(35) NOT NULL
);

--table des états de commande
CREATE TABLE etat (
    id_etat SERIAL PRIMARY KEY NOT NULL,
    libelle VARCHAR(50) NOT NULL
);

--table des commandes
CREATE TABLE commande (
    id_commande SERIAL PRIMARY KEY NOT NULL,
    date_achat DATE NOT NULL,
    utilisateur_id INTEGER REFERENCES utilisateur(id_utilisateur) ON UPDATE CASCADE NOT NULL,
    etat_id INTEGER  REFERENCES etat(id_etat) ON UPDATE CASCADE NOT NULL
);

--table des tailles de vélos
CREATE TABLE taille (
    id_taille SERIAL PRIMARY KEY NOT NULL,
    libelle_taille VARCHAR(35) NOT NULL
);

--table des types de vélos
CREATE TABLE type_velo (
    id_type_velo SERIAL PRIMARY KEY NOT NULL,
    libelle_type_velo VARCHAR(50) NOT NULL
);

--table des vélos
CREATE TABLE velo (
    id_velo SERIAL PRIMARY KEY NOT NULL,
    nom_velo VARCHAR(35) NOT NULL,
    prix_velo INTEGER,
    taille_id INTEGER REFERENCES taille(id_taille) ON UPDATE CASCADE NOT NULL,
    type_velo_id INTEGER REFERENCES type_velo(id_type_velo) ON UPDATE CASCADE NOT NULL,
    matiere VARCHAR(35) NOT NULL,
    description_velo VARCHAR(50) NOT NULL,
    fournisseur VARCHAR(35) NOT NULL,
    marque VARCHAR(35) NOT NULL
);

--table de liaison entre commande et vélo
CREATE TABLE ligne_commande (
commande_id INTEGER REFERENCES commande(id_commande) ON UPDATE CASCADE NOT NULL,
velo_id INTEGER REFERENCES velo(id_velo) ON UPDATE CASCADE NOT NULL,
prix INTEGER NOT NULL,
quantite INTEGER NOT NULL,
PRIMARY KEY (commande_id, velo_id)
);

--table représentant le panier temporaire d’un utilisateur
CREATE TABLE ligne_panier(
utilisateur_id INTEGER REFERENCES utilisateur(id_utilisateur) ON UPDATE CASCADE NOT NULL,
velo_id INTEGER REFERENCES velo(id_velo) ON UPDATE CASCADE NOT NULL,
quantite INTEGER NOT NULL,
date_ajout DATE NOT NULL,
PRIMARY KEY (utilisateur_id, velo_id)
);